/*
 * Gyro.c
 *
 *  Created on: Nov 12, 2023
 *      Author: matus
 */

#include <Gyro.h>

static GPIO_InitTypeDef gyro_cnfg;
static SPI_HandleTypeDef spi_cnfg;
static HAL_StatusTypeDef hal_status;

float x_pos_global = 0;
float x_angle = 160;

void Gyro_Slave_Enable()
{
	HAL_GPIO_WritePin(NCS_MEMS_SPI_PORT, NCS_MEMS_SPI_PIN, GPIO_PIN_RESET);
}

void Gyro_Slave_Disable()
{
	HAL_GPIO_WritePin(NCS_MEMS_SPI_PORT, NCS_MEMS_SPI_PIN, GPIO_PIN_SET);
}

void Gyro_Init()
{
	gyro_cnfg.Pin = SPI5_SCK_PIN | SPI5_MISO | SPI5_MOSI;
	gyro_cnfg.Alternate = GPIO_AF5_SPI5;
	gyro_cnfg.Mode = GPIO_MODE_AF_PP;
	gyro_cnfg.Speed = GPIO_SPEED_FREQ_MEDIUM;
	gyro_cnfg.Pull = GPIO_NOPULL;
	__HAL_RCC_GPIOF_CLK_ENABLE();
	HAL_GPIO_Init(GPIOF, &gyro_cnfg);

	gyro_cnfg.Pin = NCS_MEMS_SPI_PIN;
	gyro_cnfg.Mode = GPIO_MODE_OUTPUT_PP;
	gyro_cnfg.Speed = GPIO_SPEED_FREQ_MEDIUM;
	gyro_cnfg.Pull = GPIO_PULLUP;
	__HAL_RCC_GPIOC_CLK_ENABLE();
	HAL_GPIO_Init(GPIOC, &gyro_cnfg);

	Gyro_Slave_Disable();

	spi_cnfg.Instance = SPI5;
	spi_cnfg.Init.Mode = SPI_MODE_MASTER;
	spi_cnfg.Init.Direction = SPI_DIRECTION_2LINES;
	spi_cnfg.Init.DataSize = SPI_DATASIZE_8BIT;
	spi_cnfg.Init.CLKPolarity = SPI_POLARITY_LOW;
	spi_cnfg.Init.CLKPhase = SPI_PHASE_1EDGE;
	spi_cnfg.Init.NSS = SPI_NSS_SOFT;
	spi_cnfg.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
	spi_cnfg.Init.FirstBit = SPI_FIRSTBIT_MSB;
	spi_cnfg.Init.TIMode = SPI_TIMODE_DISABLE;
	spi_cnfg.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	spi_cnfg.Init.CRCPolynomial = 10;
	HAL_SPI_Init(&spi_cnfg);
}

void Gyro_Get_Device_ID()
{
	uint8_t DataReturned;
	uint16_t Rx = 0x00;
	uint16_t commandToSend = (READING_REG | WHO_AM_I);
	Gyro_Slave_Enable();
	while(HAL_GPIO_ReadPin(NCS_MEMS_SPI_PORT, NCS_MEMS_SPI_PIN) != GPIO_PIN_RESET);
	hal_status = HAL_SPI_TransmitReceive(&spi_cnfg, (uint8_t*)&commandToSend, (uint8_t*)&Rx, 2, DELAY);
	Gyro_Slave_Disable();
	if (hal_status != HAL_OK)
	{
		for (;;);
	}
	DataReturned = (0xFF00 & Rx) >> 8;
	printf("The Device ID is: %d\n", DataReturned);
}

void Gyro_Power_On()
{
	uint16_t commandToSend = (READING_REG | CTRL_REG1);
	uint16_t Rx = 0x00;
	Gyro_Slave_Enable();
	HAL_SPI_TransmitReceive(&spi_cnfg, (uint8_t*)&commandToSend, (uint8_t*)&Rx, 2, DELAY);
	Gyro_Slave_Disable();

	Rx = Rx >> 8;
	Rx |= POWERING;

	commandToSend = (WRITING_REG | CTRL_REG1) | (Rx << 8);
	Gyro_Slave_Enable();
	HAL_SPI_Transmit(&spi_cnfg, (uint8_t*)&commandToSend, 2, DELAY);
	Gyro_Slave_Disable();
}

void Gyro_Reboot()
{
	printf("Reboot started\n");
	uint16_t commandToSend = (READING_REG | CTRL_REG5);
	uint16_t Rx = 0x00;
	Gyro_Slave_Enable();
	hal_status = HAL_SPI_TransmitReceive(&spi_cnfg, (uint8_t*)&commandToSend, (uint8_t*)&Rx, 2, DELAY);
	Gyro_Slave_Disable();

	Rx = Rx >> 8;
	Rx |= REBOOTING;

	commandToSend = (WRITING_REG | CTRL_REG5) | (Rx << 8);
	Gyro_Slave_Enable();
	hal_status = HAL_SPI_Transmit(&spi_cnfg, (uint8_t*)&commandToSend, 2, DELAY);
	Gyro_Slave_Disable();
	Gyro_Verify_SPI_HAL();
	printf("Reboot ended\n");
}

//void Gyro_Temp_Print()
//{
//	uint8_t DataReturned;
//	uint16_t Rx = 0x00;
//	uint16_t commandToSend = (READING_REG | OUT_TEMP);
//	Gyro_Slave_Enable();
//	while(HAL_GPIO_ReadPin(NCS_MEMS_SPI_PORT, NCS_MEMS_SPI_PIN) != GPIO_PIN_RESET);
//	hal_status = HAL_SPI_TransmitReceive(&spi_cnfg, (uint8_t*)&commandToSend, (uint8_t*)&Rx, 2, DELAY);
//	Gyro_Slave_Disable();
//
//	Gyro_Verify_SPI_HAL();
//
//	DataReturned = (0xFF00 & Rx) >> 8;
//	printf("The Temperature is: %d\n", DataReturned);
//}

void Gyro_Reg_Config()
{
	uint16_t reg = 0xCF;
	uint16_t commandToSend = (WRITING_REG | CTRL_REG1) | (reg << 8);
	Gyro_Slave_Enable();
	HAL_SPI_Transmit(&spi_cnfg, (uint8_t*)&commandToSend, 2, DELAY);
	Gyro_Slave_Disable();

	reg = 0x10;
	commandToSend = (WRITING_REG | CTRL_REG4) | (reg << 8);
	Gyro_Slave_Enable();
	HAL_SPI_Transmit(&spi_cnfg, (uint8_t*)&commandToSend, 2, DELAY);
	Gyro_Slave_Disable();

	reg = 0xC0;
	commandToSend = (WRITING_REG | CTRL_REG5) | (reg << 8);
	Gyro_Slave_Enable();
	HAL_SPI_Transmit(&spi_cnfg, (uint8_t*)&commandToSend, 2, DELAY);
	Gyro_Slave_Disable();

	reg = 0x40;
	commandToSend = (WRITING_REG | FIFO_CTRL_REG) | (reg << 8);
	Gyro_Slave_Enable();
	HAL_SPI_Transmit(&spi_cnfg, (uint8_t*)&commandToSend, 2, DELAY);
	Gyro_Slave_Disable();
}

uint16_t Gyro_Axis_Xlow()
{
	// x-low
	uint8_t DataReturned;
	uint16_t Rx = 0x00;
	uint16_t commandToSend = (READING_REG | OUT_X_L);
	Gyro_Slave_Enable();
	while(HAL_GPIO_ReadPin(NCS_MEMS_SPI_PORT, NCS_MEMS_SPI_PIN) != GPIO_PIN_RESET);
	hal_status = HAL_SPI_TransmitReceive(&spi_cnfg, (uint8_t*)&commandToSend, (uint8_t*)&Rx, 2, DELAY);
	Gyro_Slave_Disable();

	Gyro_Verify_SPI_HAL();

	DataReturned = (0xFF00 & Rx) >> 8;
	return DataReturned;
//	printf("The Low X-axis is %d\n", DataReturned);
}

uint16_t Gyro_Axis_Xhigh()
{
	// x-high
	uint8_t DataReturned;
	uint16_t Rx = 0x00;
	uint16_t commandToSend = (READING_REG | OUT_X_H);
	Gyro_Slave_Enable();
	while(HAL_GPIO_ReadPin(NCS_MEMS_SPI_PORT, NCS_MEMS_SPI_PIN) != GPIO_PIN_RESET);
	hal_status = HAL_SPI_TransmitReceive(&spi_cnfg, (uint8_t*)&commandToSend, (uint8_t*)&Rx, 2, DELAY);
	Gyro_Slave_Disable();

	Gyro_Verify_SPI_HAL();

	DataReturned = (0xFF00 & Rx) >> 8;
	return DataReturned;
//	printf("The High X-axis is %d\n", DataReturned);

	// y-low
//	commandToSend = (READING_REG | OUT_Y_L);
//	Gyro_Slave_Enable();
//	while(HAL_GPIO_ReadPin(NCS_MEMS_SPI_PORT, NCS_MEMS_SPI_PIN) != GPIO_PIN_RESET);
//	hal_status = HAL_SPI_TransmitReceive(&spi_cnfg, (uint8_t*)&commandToSend, (uint8_t*)&Rx, 2, DELAY);
//	Gyro_Slave_Disable();
//
//	Gyro_Verify_SPI_HAL();
//
//	DataReturned = (0xFF00 & Rx) >> 8;
//	printf("The Low Y-axis is %d\n", DataReturned);

	// y-high
//	commandToSend = (READING_REG | OUT_Y_H);
//	Gyro_Slave_Enable();
//	while(HAL_GPIO_ReadPin(NCS_MEMS_SPI_PORT, NCS_MEMS_SPI_PIN) != GPIO_PIN_RESET);
//	hal_status = HAL_SPI_TransmitReceive(&spi_cnfg, (uint8_t*)&commandToSend, (uint8_t*)&Rx, 2, DELAY);
//	Gyro_Slave_Disable();
//
//	Gyro_Verify_SPI_HAL();
//
//	DataReturned = (0xFF00 & Rx) >> 8;
//	printf("The High Y-axis is %d\n", DataReturned);

	// z-low
//	commandToSend = (READING_REG | OUT_Z_L);
//	Gyro_Slave_Enable();
//	while(HAL_GPIO_ReadPin(NCS_MEMS_SPI_PORT, NCS_MEMS_SPI_PIN) != GPIO_PIN_RESET);
//	hal_status = HAL_SPI_TransmitReceive(&spi_cnfg, (uint8_t*)&commandToSend, (uint8_t*)&Rx, 2, DELAY);
//	Gyro_Slave_Disable();
//
//	Gyro_Verify_SPI_HAL();
//
//	DataReturned = (0xFF00 & Rx) >> 8;
//	printf("The Low Z-axis is %d\n", DataReturned);

	// z-high
//	commandToSend = (READING_REG | OUT_Z_H);
//	Gyro_Slave_Enable();
//	while(HAL_GPIO_ReadPin(NCS_MEMS_SPI_PORT, NCS_MEMS_SPI_PIN) != GPIO_PIN_RESET);
//	hal_status = HAL_SPI_TransmitReceive(&spi_cnfg, (uint8_t*)&commandToSend, (uint8_t*)&Rx, 2, DELAY);
//	Gyro_Slave_Disable();
//
//	Gyro_Verify_SPI_HAL();
//
//	DataReturned = (0xFF00 & Rx) >> 8;
//	printf("The High Z-axis is %d\n", DataReturned);
}

//float Gyro_Axis_Xtotal()
//{
//	uint16_t xLow = Gyro_Axis_Xlow();
//	uint16_t xHigh = Gyro_Axis_Xhigh();
////uint16_t xLow = 4;
//	xHigh = xHigh << 8;
//	int16_t xTotal = xHigh | xLow;
////	printf("Total x %d\n", xTotal);
//
////	if (xTotal & (1 << 15))
////	{
////		xTotal = ~xTotal;
////		xTotal = xTotal + 1;
////	}
//
////	xTotal = ((240 * xTotal) / 65535);
////	printf("Total x %d\n", xTotal);
//	float x_vel = (float)xTotal * I3G4250D_SENSITIVITY_500DPS;
//
//	float x_pos = x_vel * REGTIME;
//
//	x_pos_global = x_pos_global + x_pos;
//
//	x_angle = x_angle + x_pos_global;
//
//	return x_angle;
//}

float Gyro_Axis_Xtotal()
{
	uint16_t xLow = Gyro_Axis_Xlow();
	uint16_t xHigh = Gyro_Axis_Xhigh();
//uint16_t xLow = 4;
	xHigh = xHigh << 8;
	int16_t xTotal = xHigh | xLow;
//	printf("Total x %d\n", xTotal);

//	if (xTotal & (1 << 15))
//	{
//		xTotal = ~xTotal;
//		xTotal = xTotal + 1;
//	}

//	xTotal = ((240 * xTotal) / 65535);
//	printf("Total x %d\n", xTotal);
	float x_vel = (float)xTotal * TOTAL_VAL;

	x_pos_global = x_pos_global + x_vel;

	if (x_angle > 281 || x_angle < 21)
	{
		x_angle = 160;
		x_pos_global = 0;
	}

	x_angle = x_angle + (x_pos_global);

	return x_angle;
}

void Gyro_Verify_SPI_HAL()
{
	if (hal_status != HAL_OK)
	{
		APPLICATION_ASSERT(false);
	}
}
