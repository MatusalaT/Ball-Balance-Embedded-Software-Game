/*
 * LED_Driver.c
 *
 *  Created on: Sep 5, 2023
 *      Author: matus
 */

#include <LED_Driver.h>

static GPIO_InitTypeDef* redLED;
static GPIO_InitTypeDef* greenLED;

void LED_Init(uint8_t led)
{
	switch (led)
	{
		case RED_LED:
		{
			redLED->Pin = GPIO_PIN_14;
			redLED->Mode = GPIO_MODE_OUTPUT_PP;
			redLED->Speed = GPIO_SPEED_FREQ_MEDIUM;
			redLED->Pull = GPIO_NOPULL;
			__HAL_RCC_GPIOG_CLK_ENABLE();
			HAL_GPIO_Init(GPIOG, redLED);
			break;
		}
		case GREEN_LED:
		{
			redLED->Pin = GPIO_PIN_13;
			redLED->Mode = GPIO_MODE_OUTPUT_PP;
			redLED->Speed = GPIO_SPEED_FREQ_MEDIUM;
			redLED->Pull = GPIO_NOPULL;
			__HAL_RCC_GPIOG_CLK_ENABLE();
			HAL_GPIO_Init(GPIOG, greenLED);
			break;
		}
		default:
		{
			for (;;);
			break;
		}
	}
}

void LED_Toggle(uint8_t led)
{
	switch (led)
	{
		case RED_LED:
		{
			HAL_GPIO_TogglePin(GPIOG, redLED->Pin);
			break;
		}
		case GREEN_LED:
		{
			HAL_GPIO_TogglePin(GPIOG, greenLED->Pin);
			break;
		}
		default:
		{
			for (;;);
			break;
		}
	}
}

void LED_Disable(uint8_t led)
{
	switch (led)
	{
		case RED_LED:
		{
			HAL_GPIO_WritePin(GPIOG, redLED->Pin, GPIO_PIN_RESET);
			break;
		}
		case GREEN_LED:
		{
			HAL_GPIO_WritePin(GPIOG, greenLED->Pin, GPIO_PIN_RESET);
			break;
		}
		default:
		{
			for (;;);
			break;
		}
	}
}

void LED_Enable(uint8_t led)
{
	switch (led)
	{
		case RED_LED:
		{
			HAL_GPIO_WritePin(GPIOG, redLED->Pin, GPIO_PIN_SET);
			break;
		}
		case GREEN_LED:
		{
			HAL_GPIO_WritePin(GPIOG, greenLED->Pin, GPIO_PIN_SET);
			break;
		}
		default:
		{
			for (;;);
			break;
		}
	}
}

