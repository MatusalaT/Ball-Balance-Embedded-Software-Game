/*
 * Button_Driver.c
 *
 *  Created on: Sep 26, 2023
 *      Author: matus
 */

#include <Button_Driver.h>

void Button_Init()
{
//	GPIO_Handle_t Button_Config = {0};
//	Button_Config.pGPIOx = BUTTON_PORT;
//	Button_Config.GPIO_PinConfig.PinNumber = BUTTON_PIN;
//	Button_Config.GPIO_PinConfig.PinMode = PIN_MODE_INPUT;
//	Button_Clock_Enable();

	GPIO_InitTypeDef* Button_Config2 = {0};

	Button_Config2->Pin = GPIO_PIN_0;
	Button_Config2->Mode = GPIO_MODE_INPUT;
	Button_Clock_Enable();
	HAL_GPIO_Init(GPIOA, Button_Config2);
}

void Button_Clock_Enable()
{
//	GPIO_Enable_Clock(BUTTON_PORT, ENABLE);
	__HAL_RCC_GPIOA_CLK_ENABLE();
}

bool Button_Press()
{
//	if (GPIO_Read(BUTTON_PORT, BUTTON_PIN) == BUTTON_PRESS)
//	{
//		return true;
//	}
//	if (GPIO_Read(BUTTON_PORT, BUTTON_PIN) == BUTTON_UNPRESS)
//	{
//		return false;
//	}
//	return 0;
	if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == BUTTON_PRESS)
	{
		return true;
	}
	if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == BUTTON_UNPRESS)
	{
		return false;
	}
	return 0;
}

void Intrpt_Btn_Init()
{
	GPIO_InitTypeDef Intrpt_Config = {0};
	Intrpt_Config.Pin = GPIO_PIN_0;
	Intrpt_Config.Mode = GPIO_MODE_IT_RISING;
	Intrpt_Config.Pull = GPIO_NOPULL;
	Intrpt_Config.Speed = GPIO_SPEED_FREQ_MEDIUM;
	Button_Clock_Enable();
	HAL_GPIO_Init(GPIOA, &Intrpt_Config);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
}
