/*
 * ErrorHandling.c
 *
 *  Created on: Nov 9, 2023
 *      Author: matus
 */

#include <ErrorHandling.h>
void APPLICATION_ASSERT(bool checker)
{
	if (checker == false)
	{
		while (1)
		{
		}
	}
}
