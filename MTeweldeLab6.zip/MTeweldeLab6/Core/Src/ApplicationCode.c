/*
 * ApplicationCode.c
 *
 *  Created on: Sep 5, 2023
 *      Author: matus
 */


#include <ApplicationCode.h>

static uint8_t Current_LED;

void Green_Init()
{
	LED_Init(GREEN_LED);
}

void Red_Init()
{
	LED_Init(RED_LED);
}

void RG_Init()
{
	LED_Init(GREEN_LED);
	LED_Init(RED_LED);
}

void Green_Toggle()
{
	LED_Toggle(GREEN_LED);
}

void Red_Toggle()
{
	LED_Toggle(RED_LED);
}

void Green_Activate()
{
	LED_Enable(GREEN_LED);
}

void Red_Activate()
{
	LED_Enable(RED_LED);
}

void Green_Deactivate()
{
	LED_Disable(GREEN_LED);
}

void Red_Deactivate()
{
	LED_Disable(RED_LED);
}

void delay(uint32_t time)
{
	char myName [NAMESIZE] = {'M', 'A', 'T', 'U', 'S', 'A', 'L', 'A'};
	[[maybe_unused]]char nameDestination [NAMESIZE];

	for (uint32_t i = 0; i < time; i++)
	{
		for (uint32_t j = 0; j < NAMESIZE; j++)
		{
			nameDestination[j] = myName[j];
		}
	}
	return;
}

void Application_Init()
{
	// Red_Init();
	// addSchedulerEvent(LED_TOGGLE);
	// addSchedulerEvent(DELAY_EVENT);

//	Green_Init();
//	Red_Init();
//
//	Current_LED = LED_GREEN;
//	Green_Deactivate();

//	addSchedulerEvent(LED_TOGGLE);
//	addSchedulerEvent(DELAY_EVENT);
//	Intrpt_Btn_Init();
	App_Gyro_Init();
	Intrpt_Btn_Init();
//	addSchedulerEvent(TEMP_EVENT);
//	addSchedulerEvent(AXIS_DATA_EVENT);
////	addSchedulerEvent(REBOOT_CMD_EVENT);
//
//	#if USE_INTERRUPT_FOR_BUTTON==0 // This checks if it is set to 0.
//		App_Button_Init();
//		addSchedulerEvent(BUTTON_POLL);
//	#elif USE_INTERRUPT_FOR_BUTTON == 1 // Similar to above, checks if USE_SPECIAL_FUNCTION is equal to 1
//		Btn_Init_Intrpt_Mode();
//	#endif

	LTCD__Init();
	LTCD_Layer_Init(0);
	LCD_Clear(0,LCD_COLOR_WHITE);
}

void App_Button_Init()
{
	Button_Init();
}

void executeButtonPollingRoutine()
{
	if (Button_Press() == true)
	{
		if (Current_LED == LED_GREEN)
		{
			Green_Activate();
		}
		if (Current_LED == LED_RED)
		{
			Red_Deactivate();
		}
	}
	if (Button_Press() == false)
	{
		if (Current_LED == LED_GREEN)
		{
			Green_Deactivate();
		}
		if (Current_LED == LED_RED)
		{
			Red_Deactivate();
		}
	}
	return;
}

#if USE_INTERRUPT_FOR_BUTTON == 1 // Similar to above, checks if USE_SPECIAL_FUNCTION is equal to 1
	void Btn_Init_Intrpt_Mode()
	{
		Intrpt_Btn_Init();
	}


	void EXTI0_IRQHandler()
	{
		IRQ_Interrupt_Disable(EXTI0_IRQn);

		App_LCD_Game_Reset();

		// start game function
		addSchedulerEvent(REBOOT_GAME_EVENT);

		IRQ_Interrupt_Clear(EXTI0_IRQn);
		IRQ_Pending_Clr_Bit(BUTTON_PIN);
		IRQ_Interrupt_Enable(EXTI0_IRQn);
	}
#endif

void App_Gyro_Init()
{
	Gyro_Init();
}

void App_Gyro_Get_Device_ID()
{
	Gyro_Get_Device_ID();
}

void App_Gyro_Power_on()
{
	Gyro_Power_On();
}

void App_Gyro_Reboot()
{
	Gyro_Reboot();
}

void App_Gyro_Reg_Config()
{
	Gyro_Reg_Config();
}

//void App_Gyro_Axis_Data()
//{
//	Gyro_Axis_Data();
//}

float App_Gyro_Axis_Xtotal()
{
	return Gyro_Axis_Xtotal();
}

//void App_Ball_Display()
//{
//	Ball_Display();
//}

void RunDemoForLCD(void)
{
	QuickDemo();
}

void App_LCD_Game_Start()
{
	LCD_Game_Start();
}

void App_LCD_Game_Reset()
{
	LCD_Game_Reset();
}

void App_LCD_Game_End(uint32_t start_time)
{
	LCD_Game_End(start_time);
}
