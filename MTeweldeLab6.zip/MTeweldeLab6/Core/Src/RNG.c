/*
 * RNG.c
 *
 *  Created on: Dec 4, 2023
 *      Author: matus
 */

#include "RNG.h"
static RNG_HandleTypeDef RNG_Config;
HAL_StatusTypeDef status;
uint32_t RNG_var;
uint32_t RNG_var1;
void RNG_Init(){
	RNG_Config.ErrorCode = 0;
	RNG_Config.Instance= RNG;
	RNG_Config.Lock = HAL_UNLOCKED;
	RNG_Config.RandomNumber = 0;
	RNG_Config.State = HAL_RNG_STATE_RESET;
	__HAL_RCC_RNG_CLK_ENABLE();

	status = HAL_RNG_Init(&RNG_Config);
	if(status != HAL_OK){
		for(;;);
	}
}

uint32_t GetRNG()
{
	status = HAL_RNG_GenerateRandomNumber(&RNG_Config,&RNG_var);
	if(status != HAL_OK)
	{
		for(;;);
	}
	RNG_var1 = RNG_var % 160;
	if (RNG_var1 < 0)
	{
		RNG_var1 = RNG_var1 * (-1);
	}
	return RNG_var1;
}
