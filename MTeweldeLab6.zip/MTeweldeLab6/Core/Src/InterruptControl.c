/*
 * InterruptControl.c
 *
 *  Created on: Oct 3, 2023
 *      Author: matus
 */

#include <InterruptControl.h>
#include <stdint.h>

void IRQ_Interrupt_Enable(uint8_t IRQ_Number)
{
//	if (IRQ_Number < 32)
//	{
//		*NVIC_ISER0 |= (1 << IRQ_Number);
//	}
//	if (IRQ_Number >= 32)
//	{
//		*NVIC_ISER1 |= (1 << IRQ_Number % 32);
//	}
	HAL_NVIC_EnableIRQ(IRQ_Number);
}

void IRQ_Interrupt_Disable(uint8_t IRQ_Number)
{
//	if (IRQ_Number < 32)
//	{
//		*NVIC_ICER0 |= (1 << IRQ_Number);
//	}
//	if (IRQ_Number >= 32)
//	{
//		*NVIC_ICER1 |= (1 << IRQ_Number % 32);
//	}
	HAL_NVIC_DisableIRQ(IRQ_Number);
}

void IRQ_Interrupt_Clear(uint8_t IRQ_Number)
{
//	if (IRQ_Number < 32)
//	{
//		*NVIC_ICPR0 |= (1 << IRQ_Number);
//	}
//	if (IRQ_Number >= 32)
//	{
//		*NVIC_ICPR0 |= (1 << IRQ_Number % 32);
//	}
	HAL_NVIC_ClearPendingIRQ(IRQ_Number);
}

void IRQ_Interrupt_Set(uint8_t IRQ_Number)
{
//	if (IRQ_Number < 32)
//	{
//		*NVIC_ISPR0 |= (1 << IRQ_Number);
//	}
//	if (IRQ_Number >= 32)
//	{
//		*NVIC_ISPR1 |= (1 << IRQ_Number % 32);
//	}
	HAL_NVIC_SetPendingIRQ(IRQ_Number);
}

void IRQ_Pending_Clr_Bit(uint8_t Pin)
{
	EXTI->PR |= (1 << Pin);
}

