/*
 * Gyro.h
 *
 *  Created on: Nov 12, 2023
 *      Author: matus
 */

#ifndef INC_GYRO_H_
#define INC_GYRO_H_

#include <stm32f4xx_hal.h>
#include <ErrorHandling.h>
#include <stdio.h>

#define WHO_AM_I                   0x0F
#define CTRL_REG1                  0x20
#define CTRL_REG2                  0x21
#define CTRL_REG3                  0x22
#define CTRL_REG4                  0x23
#define CTRL_REG5                  0x24
#define REFERENCE_DATACAPTURE      0x25
#define OUT_TEMP                   0x26
#define STATUS_REG                 0x27
#define OUT_X_L                    0x28
#define OUT_X_H                    0x29
#define OUT_Y_L                    0x2A
#define OUT_Y_H                    0x2B
#define OUT_Z_L                    0x2C
#define OUT_Z_H                    0x2D
#define FIFO_CTRL_REG              0x2E
#define FIFO_SRC_REG               0x2F
#define INT1_CFG                   0x30
#define INT1_SRC                   0x31
#define INT1_THS_XH                0x32
#define INT1_THS_XL                0x33
#define INT1_THS_YH                0x34
#define INT1_THS_YL                0x35
#define INT1_THS_ZH                0x36
#define INT1_THS_ZL                0x37
#define INT1_DURATION              0x38

#define SPI_PORT                   GPIOF
#define SPI5_SCK_PIN               GPIO_PIN_7
#define SPI5_MISO                  GPIO_PIN_8
#define SPI5_MOSI                  GPIO_PIN_9
#define NCS_MEMS_SPI_PORT          GPIOC
#define NCS_MEMS_SPI_PIN           GPIO_PIN_1
#define MEMS_INT_PORT              GPIOA
#define MEMS_INT2_PIN              GPIO_PIN_2
#define MEMS_INT1_PIN              GPIO_PIN_1

#define DELAY                      1000

#define REBOOTING                  (1 << 7)
#define WRITING_REG                (0 << 7)
#define READING_REG                (1 << 7)
#define POWERING                   (1 << 3)

#define I3G4250D_SENSITIVITY_245DPS  ((float)8.75f)         /*!< gyroscope sensitivity with 250 dps full scale [DPS/LSB]  */
#define I3G4250D_SENSITIVITY_500DPS  ((float)17.50f)        /*!< gyroscope sensitivity with 500 dps full scale [DPS/LSB]  */
#define I3G4250D_SENSITIVITY_2000DPS ((float)70.00f)        /*!< gyroscope sensitivity with 2000 dps full scale [DPS/LSB] */
#define REGTIME                      ((float)0.00125)

#define TOTAL_VAL                    (REGTIME * 0.0015 * I3G4250D_SENSITIVITY_500DPS)

void Gyro_Init();
void Gyro_Get_Device_ID();
void Gyro_Power_On();
void Gyro_Reboot();
void Gyro_Reg_Config();
void Gyro_Verify_SPI_HAL();
void Gyro_Slave_Enable();
void Gyro_Slave_Disable();
uint16_t Gyro_Axis_Xlow();
uint16_t Gyro_Axis_Xhigh();
float Gyro_Axis_Xtotal();

#endif /* INC_GYRO_H_ */
