/*
 * Scheduler.h
 *
 *  Created on: Sep 5, 2023
 *      Author: matus
 */

#ifndef SCHEDULER_H_
#define SCHEDULER_H_

#include <stdint.h>
#include <Button_Driver.h>

#define LED_TOGGLE          (0x1 << 0)
#define DELAY_EVENT         (0x1 << 1)
#define BUTTON_POLL	        (0x1 << 2)
#define TEMP_EVENT          (0X1 << 3)
#define AXIS_DATA_EVENT     (0X1 << 4)
#define REBOOT_GAME_EVENT   (0x1 << 5)
#define GAME_START          (0x1 << 6)
#define BEGIN_GAME          (0x1 << 7)

uint32_t getScheduledEvents(void);
void addSchedulerEvent(uint32_t event);
void removeSchedulerEvent(uint32_t event);

#endif /* SCHEDULER_H_ */
