/*
 * Button_Driver.h
 *
 *  Created on: Sep 26, 2023
 *      Author: matus
 */

#ifndef BUTTON_DRIVER_H_
#define BUTTON_DRIVER_H_

#include <stdbool.h>
#include <InterruptControl.h>
#include <stm32f4xx_hal.h>

#define BUTTON_PIN       0
#define BUTTON_PRESS     1
#define BUTTON_UNPRESS   0
#define BUTTON_PORT	     GPIOA

void Button_Init();
void Button_Clock_Enable();
bool Button_Press();
void Intrpt_Btn_Init();

#endif /* BUTTON_DRIVER_H_ */
