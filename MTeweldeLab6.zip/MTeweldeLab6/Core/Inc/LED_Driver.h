/*
 * LED_Driver.h
 *
 *  Created on: Sep 5, 2023
 *      Author: matus
 */

#ifndef LED_DRIVER_H_
#define LED_DRIVER_H_
#define GREEN_LED      1
#define RED_LED        0

#include <stm32f4xx_hal.h>

void LED_Init(uint8_t led);
void Clock_Enable(uint8_t led);
void LED_Enable(uint8_t led);
void LED_Disable(uint8_t led);
void LED_Toggle(uint8_t led);

#endif /* LED_DRIVER_H_ */
