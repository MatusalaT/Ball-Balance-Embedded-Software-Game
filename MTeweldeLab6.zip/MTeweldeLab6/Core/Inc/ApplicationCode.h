/*
 * ApplicationCode.h
 *
 *  Created on: Sep 5, 2023
 *      Author: matus
 */

#ifndef APPLICATIONCODE_H_
#define APPLICATIONCODE_H_
#define NAMESIZE 8
#define MAGNIFYDELAY 250000

#include <LED_Driver.h>
#include <Scheduler.h>
#include <Gyro.h>
#include "LCD_Driver.h"
#include <stdio.h>

// maybe delete
#define LED_RED 0
#define LED_GREEN 1

#define USE_INTERRUPT_FOR_BUTTON 1

void Application_Init();
// Initialize LED
void Green_Init();
void Red_Init();
void RG_Init();

// Toggle LED
void Green_Toggle();
void Red_Toggle();

// Activate (Turn on) LED
void Green_Activate();
void Red_Activate();

// Deactivate (Turn off) LED
void Green_Deactivate();
void Red_Deactivate();

// Delay function
void delay(uint32_t time);

void App_Button_Init();
void executeButtonPollingRoutine();

void Btn_Init_Intrpt_Mode();

void App_Gyro_Init();
void App_Gyro_Get_Device_ID();
void App_Gyro_Power_on();
void App_Gyro_Reboot();
//void App_Gyro_Temp_Print();
void App_Gyro_Reg_Config();
float App_Gyro_Axis_Xtotal();

void RunDemoForLCD(void);
void App_Ball_Display();
void App_LCD_Game_Start();
void App_LCD_Game_Reset();
void App_LCD_Game_End(uint32_t start_time);
#endif /* APPLICATIONCODE_H_ */
