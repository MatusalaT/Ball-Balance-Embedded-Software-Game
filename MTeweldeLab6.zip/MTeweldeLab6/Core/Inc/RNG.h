/*
 * RNG.h
 *
 *  Created on: Dec 4, 2023
 *      Author: matus
 */

#ifndef INC_RNG_H_
#define INC_RNG_H_

#include "stm32f4xx_hal.h"

void RNG_Init();
uint32_t GetRNG();

#endif /* INC_RNG_H_ */
