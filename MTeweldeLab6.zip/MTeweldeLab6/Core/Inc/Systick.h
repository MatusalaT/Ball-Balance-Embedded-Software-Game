/*
 * Systick.h
 *
 *  Created on: Dec 4, 2023
 *      Author: matus
 */

#ifndef INC_SYSTICK_H_
#define INC_SYSTICK_H_

void startTick();
void endTick();

#endif /* INC_SYSTICK_H_ */
