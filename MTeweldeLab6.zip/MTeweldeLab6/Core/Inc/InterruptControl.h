/*
 * InterruptControl.h
 *
 *  Created on: Oct 3, 2023
 *      Author: matus
 */

#ifndef INTERRUPTCONTROL_H_
#define INTERRUPTCONTROL_H_

#include <stdint.h>
#include <stm32f4xx_hal.h>

#define EXTI0_IRQ_NUMBER 6

void IRQ_Interrupt_Enable(uint8_t IRQ_Number);
void IRQ_Interrupt_Disable(uint8_t IRQ_Number);
void IRQ_Interrupt_Clear(uint8_t IRQ_Number);
void IRQ_Interrupt_Set(uint8_t IRQ_Number);
void IRQ_Pending_Clr_Bit(uint8_t Pin);

#endif /* INTERRUPTCONTROL_H_ */
